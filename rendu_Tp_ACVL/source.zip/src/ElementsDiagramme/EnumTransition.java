package ElementsDiagramme;

import java.io.Serializable;

/**
 * Created by Jerem on 08/11/2015.
 */
public enum EnumTransition implements Serializable {
    INTER,
    INIT,
    FINAL;
}
