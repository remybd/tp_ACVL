package Vues;

import Controleurs.ControleurDiagramme;

/**
 * Created by Jerem on 03/11/2015.
 */
public class Suppression extends FenetrePopup {
    public Suppression(ControleurDiagramme controleur){
        super();
    }
}
