package Vues;

public enum EnumObjetSelectionne {
	AUCUN, ETAT, TRANSITION;
}
