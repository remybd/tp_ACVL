package Vues;

import java.io.Serializable;

/**
 * Created by r�my on 05/11/2015.
 */
public interface ObservateurVue extends Serializable{
    void miseAJour();
}
