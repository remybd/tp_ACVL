package ElementsDiagramme;

import java.io.Serializable;

/**
 * Created by Jerem on 08/11/2015.
 */
public enum EnumEtat implements Serializable{
    SIMPLE,
    COMPOSITE,
    INIT,
    FINAL;
}
